import { Component } from '@angular/core';
import { theAdventure } from './data';
import { Scene } from './scene';
import { Adventure } from './adventure';
import { GameState } from './gameState';
import { Option } from './option';
import { SceneComponent } from './sceneComponent';

@Component({
  selector: 'app',
  template: `
  <div class="">
    <h1>{{adventure.title}}</h1>
    <scene [scene]="getCurrentScene()" (out)="setScene($event)" (reset)="resetGame($event)"></scene>
    <br>
  </div>
  `,
  styles: ['.parent {background-color: grey;}']
})
export class AppComponent {

  adventure: Adventure;
  gameState: GameState;

  constructor() {
    this.resetGame();
  }

  setScene(option: Option):void {
    this.gameState.currentScene = option.sceneName;    
    this.gameState.numberOfSteps++;
  }

  getCurrentScene():Scene {
    return this.adventure.scenes[this.gameState.currentScene];
  }

  resetGame() {
    this.adventure = {...theAdventure};
    this.gameState = {...this.adventure.gameState};
  }

}
