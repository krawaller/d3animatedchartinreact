import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Scene } from './scene';
import { Option } from './option';

@Component({
  selector: 'scene',
  template: `
  <div [class.dead]="gameOver" class="">
    <h3>{{theScene.title}}</h3>
    <div *ngIf="!gameOver">
      <img [src]="theScene.imgUrl">
      <p>{{theScene.text}}</p>  
      <div *ngIf="theScene.options[0]">
        <p><strong>Where do you want to go?</strong></p>
        <ul>
          <li class="selectable" *ngFor="let option of theScene.options" (click)="changeScene(option)">{{option.text}}</li>
        </ul>
      </div>
      <div *ngIf="!theScene.options[0]"><p class="selectable"  (click)="resetGame(true)">Play again!</p></div>
    </div>
    <p class="selectable" *ngIf="gameOver" (click)="resetGame(false)">Try again!</p>
  </div>
  `,
  styles: ['img {max-width: 500px; max-height: 300px;}',
        '.selectable {cursor: pointer; user-select: none;}',
        '.dead {background-color: blue; color: white;}',
        '.child {background-color: yellow;}']
})
export class SceneComponent {

  theScene:Scene;

  @Output() out = new EventEmitter<Option>();
  @Output() reset = new EventEmitter<boolean>();

  @Input() set scene(scene: Scene) {
    this.theScene = scene;
  }
    
  changeScene(option: Option):void {
    this.theScene = null;
    this.out.emit(option);
  }

  resetGame(success:boolean):void {
    this.reset.emit(success);
  }

  get gameOver() {
    return this.theScene.gameOver;
  }

}