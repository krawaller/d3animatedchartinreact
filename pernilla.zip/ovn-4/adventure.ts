import { Scene } from './scene';
import { GameState } from './gameState';

export interface Adventure {
    title: string;
    startScene: string;
    scenes: {
        [key: string]: Scene
    }
    gameState: GameState;
}