export interface GameState {
    currentScene: string;
    numberOfSteps: number;
}