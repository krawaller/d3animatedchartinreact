import { Component } from '@angular/core';
import { theAdventure } from './data';
import { Scene } from './scene';
import { Adventure } from './adventure';
import { GameState } from './gameState';
import { Option } from './option';

@Component({
  selector: 'app',
  template: `
  <div [class.dead]="gameOver">
    <h1>{{adventure.title}}</h1>
    <h3>{{scene.title}}</h3>
    <div *ngIf="!gameOver">
      <img [src]="scene.imgUrl">
      <p>{{scene.text}}</p>  
      <p><strong>Where do you want to go?</strong></p>
      <ul>
        <li class="selectable" *ngFor="let option of scene.options" (click)="setScene(option)">{{option.text}}</li>
      </ul>
    </div>

    <p class="selectable" *ngIf="gameOver" (click)="resetGame()">Play again!</p>
    <pre>{{gameState | json}}</pre>
  </div>
  `,
  styles: ['img {max-width: 500px; max-height: 300px;}',
        '.selectable {cursor: pointer; user-select: none;}',
        '.dead {background-color: blue; color: white;}']
})
export class AppComponent {

  adventure: Adventure;
  gameState: GameState;

  constructor() {
    this.resetGame();
  }

  setScene(option: Option):void {
    this.gameState.currentScene = option.sceneName;
    this.gameState.numberOfSteps++;
  }

  get scene() {
    return this.adventure.scenes[this.gameState.currentScene];
  }

  get gameOver():boolean {
    return this.scene.gameOver;
  }

  resetGame() {
    this.adventure = {...theAdventure};
    this.gameState = {...this.adventure.gameState};
  }

}
