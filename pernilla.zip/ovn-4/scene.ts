import { Option } from './option';

export interface Scene {
    title: string;
    imgUrl: string;
    text: string;   
    options: Option[];
    gameOver: boolean;
}