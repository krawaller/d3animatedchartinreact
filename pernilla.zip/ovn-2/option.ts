export interface Option {
    text: string;
    sceneName: string;
}