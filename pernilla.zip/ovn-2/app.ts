import { Component } from '@angular/core';
import { theAdventure } from './data';
import { Scene } from './scene';
import { Adventure } from './adventure';
import { GameState } from './gameState';

@Component({
  selector: 'app',
  template: `
  <h1>{{adventure.title}}</h1>
  <h3>{{scene.title}}</h3>

  <img [src]="scene.imgUrl">

  <p>{{scene.text}}</p>
  
  <p><strong>Where do you want to go?</strong></p>
  <ul>
    <li *ngFor="let option of scene.options" (click)="setScene(option.sceneName)">{{option.text}}</li>
  </ul>
  `,
  styles: ['img {max-width: 500px; max-height: 300px;}']
})
export class AppComponent {

  adventure: Adventure = theAdventure;
  gameState: GameState = this.adventure.gameState;

  constructor() {
    this.setScene(this.gameState.currentScene);
  }

  setScene(newScene: string):void {
    this.gameState.currentScene = newScene;
  }

  get scene() {
    return this.adventure.scenes[this.gameState.currentScene];
  }

}
