export const theAdventure = {
    title: "A forest adventure",
    scenes: {
        forestPath: {
            title: "Forest path",
            imgUrl: "http://www.mobygames.com/images/shots/l/578490-simon-the-sorcerer-ipad-screenshot-middle-of-the-forest.png",
            text: `Strip steak filet mignon short ribs ham, shoulder beef swine t-bone picanha leberkas. 
            Porchetta drumstick hamburger tenderloin, pork chop burgdoggen sausage. 
            Turducken ham jowl, bresaola pancetta filet mignon jerky short ribs.`,
            options: [{text:"Into the cave", sceneName: "cave"}, 
                      {text:"Up the steps", sceneName: "gollum"}, 
                      {text:"To the right", sceneName: "cottage"}]
        },
        cave: {
            title: "The cave",
            imgUrl: "https://lh6.ggpht.com/yaLItUjBrVREvQN3WlvFWLyrR5LHF_bG_UoJwqbIF-Jze7-pO06CQ_T-8A7q50PxIg=h900",
            text: `Bacon ipsum dolor amet filet mignon ham hock salami kevin andouille, 
            fatback tongue strip steak.`,
            options: [{text:"Get out of cave", sceneName: "forestPath"}]
        },
        cottage: {
            title: "The cottage",
            imgUrl: "https://www.video-games-museum.com/en/screenshots/Amiga%20CD32/4/23865-ingame-Simon-the-Sorcerer.png",
            text: `Turducken chuck pork belly ball tip drumstick. 
            Brisket t-bone ribeye, biltong boudin jerky chicken burgdoggen ham fatback spare ribs. `,
            options: [{text:"Back to forest", sceneName: "forestPath"}]
        },
        gollum: {
            title: "Gollum",
            imgUrl: "https://lh4.ggpht.com/H59-roBOt5zIZmNemqqZzUlRIRHQ9ZOR9riCX-e3GNJ4Cev3i3KvVdUyy8HrSHpsFg=h900",
            text: `Short loin pork belly shoulder doner jerky beef 
            bresaola picanha filet mignon tenderloin corned beef. `,
            options: [{text:"Back to forest", sceneName: "forestPath"}]
        }
    },
    gameState: {
        currentScene: "forestPath"
    } 
}