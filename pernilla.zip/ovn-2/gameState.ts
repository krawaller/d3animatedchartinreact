export interface GameState {
    currentScene: string;
}