import { Component } from '@angular/core';

@Component({
  selector: 'app',
  template: `
  <h1>The exciting quest</h1>
  <h3>A forest path</h3>

  <img src="http://www.mobygames.com/images/shots/l/578490-simon-the-sorcerer-ipad-screenshot-middle-of-the-forest.png">

  <p>Bacon ipsum dolor amet filet mignon ham hock salami kevin andouille, 
    fatback tongue strip steak. Short loin pork belly shoulder doner jerky beef 
    bresaola picanha filet mignon tenderloin corned beef. Turducken chuck pork belly ball tip drumstick. 
    Brisket t-bone ribeye, biltong boudin jerky chicken burgdoggen ham fatback spare ribs. 
    Strip steak filet mignon short ribs ham, shoulder beef swine t-bone picanha leberkas. 
    Porchetta drumstick hamburger tenderloin, pork chop burgdoggen sausage. 
    Turducken ham jowl, bresaola pancetta filet mignon jerky short ribs.</p>
  
  <ul>
    <li>Into the cave</li>
    <li>Up the steps</li>
    <li>To the right</li>
  </ul>
  `,
  styles: ['img {max-width: 500px; max-height: 300px;}']
})
export class AppComponent {}
