import { ForkJoinObservable } from './ForkJoinObservable';
export declare const forkJoin: typeof ForkJoinObservable.create;
