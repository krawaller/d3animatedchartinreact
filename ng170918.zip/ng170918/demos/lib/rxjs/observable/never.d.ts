import { NeverObservable } from './NeverObservable';
export declare const never: typeof NeverObservable.create;
