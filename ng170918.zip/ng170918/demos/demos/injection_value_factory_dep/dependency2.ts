export default class Dependency2 {
  bar: number = 42
}