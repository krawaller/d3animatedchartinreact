import { Component } from '@angular/core';

@Component({
  selector: 'app',
  template: `
    <p>Add your template code here! :)<p>
  `,
  styles: []
})
export class AppComponent {}
