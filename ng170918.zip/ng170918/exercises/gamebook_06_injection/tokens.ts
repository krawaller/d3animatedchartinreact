import { OpaqueToken } from '@angular/core'

export const AdventureToken = new OpaqueToken("adventure")