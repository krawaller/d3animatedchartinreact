import { GameState } from './interfaces'

const SAVEKEY = 'GAMEITEM'

export class StateHandler {
  private listeners = []
  private state: GameState = JSON.parse(localStorage.getItem(SAVEKEY) || "{}" )
  listen(callback) {
    this.listeners.push(callback);
    callback(this.state);
  }
  update(state: GameState) {
    this.state = state;
    localStorage.setItem( SAVEKEY, JSON.stringify(state) );
    this.listeners.forEach( cb=> cb(state) );
  }
}
