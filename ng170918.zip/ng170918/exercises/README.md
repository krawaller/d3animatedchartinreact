So! This is the **starter kit** referred to in the exercise instructions!

This folder should be **zipped up and provided to the students**, except you **shouldn't include**:

* this file
* node_modules
* gamebook_0x (since these are the solutions)

Everything else, including the `_seed` folder and `build.js` file, should be there.

To build the solutions you follow the instructions in the first exercise, as it is the same procedure the students would follow! That is, navigate to this folder in a node terminal and do `node build foldername`.