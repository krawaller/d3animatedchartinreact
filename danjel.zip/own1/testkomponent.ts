import { Component, Input, Output, EventEmitter } from '@angular/core';

import {gameState} from './data';

@Component({
  selector: 'testkomponent',
  template: `<div *ngIf="goBackEnabled"><button (click)='goBack()'>Börja om</button></div>`,
  styles: []
})
export class TestComponent {
  @Input('page') page:gameState
  @Output() restart = new EventEmitter<void>()
  goBack(){
    this.restart.emit();
  }
  get goBackEnabled() {
    return this.page.currentPage!=='startstate';
  }
}
