import { Component } from '@angular/core';

import advData from './data';
import {pageOption} from './data';

@Component({
  selector: 'minkomponent',
  templateUrl: `page1.html`,
  styles: ['img {max-width:400px; max-height:200px}']
})
export class AppComponent {
  adv = advData;
  gameState = this.adv.inState;
  startState = {...this.adv.inState};
  get pageData() {
    return this.adv.pages[this.gameState.currentPage];
  } 
  gotoPage = function(opt:pageOption) {
    this.gameState.currentPage = opt.targetState;
  }
  goBack = function() {
    this.gameState = {...this.startState};
  }

}
