type adventure = {
    title: string,
    inState: gameState,
    pages: {
        [index: string]: page
    }
}

type page = {
    headLine: string,
    imgUrl: string,
    description: string,
    optionsArray: pageOption[]
}

export type gameState = {
    currentPage:string
}

export type pageOption = {
    optionText:string,
    targetState: string
}

const myAdventure : adventure= {
    title: 'Fruktuppdraget',
    inState: {
        currentPage:'startstate'
    },
    pages: {
        startstate:{
            headLine: 'Alla typer av frukter',
            imgUrl: 'http://www.thehealthsite.com/wp-content/uploads/2014/06/fruits.jpg',
            description:'Ditt uppdrag är att välja rätt typ av frukt',
            optionsArray: [
                {optionText:'Ananas', targetState:'wrongfruit'},
                {optionText:'Banan', targetState:'wrongfruit'},
                {optionText:'Citron', targetState:'correctfruit'},
                {optionText:'Dadlar', targetState:'wrongfruit'},
            ]
        },
        wrongfruit: {
            headLine: 'fel fel fel',
            imgUrl: 'https://skyvisionsolutions.files.wordpress.com/2015/11/catastrophic-meter-failure.jpg',
            description:'Det var tyvärr fel frukt',
            optionsArray: []
        },
        correctfruit: {
            headLine: 'Korrekt',
            imgUrl: 'https://alphabaymarket.com/wp-content/uploads/2016/12/deal.jpg-300x194.png',
            description:'Det har valt korrekt frukt',
            optionsArray: []
        }
        
    }
    
}

export default myAdventure;