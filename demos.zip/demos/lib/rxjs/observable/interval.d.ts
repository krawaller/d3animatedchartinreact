import { IntervalObservable } from './IntervalObservable';
export declare const interval: typeof IntervalObservable.create;
