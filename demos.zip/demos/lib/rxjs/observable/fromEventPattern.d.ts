import { FromEventPatternObservable } from './FromEventPatternObservable';
export declare const fromEventPattern: typeof FromEventPatternObservable.create;
