import { WebSocketSubject } from './WebSocketSubject';
export declare const webSocket: typeof WebSocketSubject.create;
